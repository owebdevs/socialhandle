"use client"

import { useState } from "react"
import { Home, Instagram, Youtube, Twitter, Sun, Moon, TrendingUp, Users, Bot, Globe, BarChart2 } from "lucide-react"
import { useTheme } from "next-themes"
import { signIn, signOut, useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import NavItem from "@/components/NavItem"
import StatCard from "@/components/StatCard"
import AIChat from "@/components/AIChat"
import InstagramContent from "@/components/InstagramContent"
import YouTubeContent from "@/components/YouTubeContent"
import TwitterContent from "@/components/TwitterContent"
import SearchBox from "@/components/SearchBox"

const MainDashboard = () => {
  const [activeTab, setActiveTab] = useState("home")
  const { theme, setTheme } = useTheme()
  const [showChat, setShowChat] = useState(false)
  const { data: session } = useSession()

  const platformColors = {
    twitter: { primary: "bg-blue-500", secondary: "bg-blue-100", text: "text-blue-500" },
    instagram: { primary: "bg-pink-500", secondary: "bg-pink-100", text: "text-pink-500" },
    youtube: { primary: "bg-red-500", secondary: "bg-red-100", text: "text-red-500" },
  }

  const getPlatformColor = () => {
    return platformColors[activeTab] || { primary: "bg-gray-500", secondary: "bg-gray-100", text: "text-gray-500" }
  }

  const HomeContent = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Total Followers" value="85.2K" icon={Users} trend={3.2} />
        <StatCard title="Total Engagement" value="12.8K" icon={TrendingUp} trend={1.5} />
        <StatCard title="Post Reach" value="152K" icon={Globe} trend={4.8} />
        <StatCard title="Growth Rate" value="2.4%" icon={BarChart2} trend={0.3} />
      </div>
    </div>
  )

  const handleSignIn = async () => {
    await signIn("google")
  }

  const handleSignOut = async () => {
    await signOut()
  }

  return (
    <div className={`min-h-screen ${theme === "dark" ? "bg-gray-900 text-white" : "bg-gray-50"}`}>
      <nav
        className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} border-b px-6 py-3`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <NavItem
              id="home"
              icon={Home}
              label="Home"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              theme={theme}
            />
            <NavItem
              id="instagram"
              icon={Instagram}
              label="Instagram"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              theme={theme}
            />
            <NavItem
              id="youtube"
              icon={Youtube}
              label="YouTube"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              theme={theme}
            />
            <NavItem
              id="twitter"
              icon={Twitter}
              label="Twitter"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              theme={theme}
            />
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className={`p-2 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <button
              onClick={() => setShowChat(true)}
              className={`flex items-center space-x-2 px-4 py-2 ${getPlatformColor().primary} text-white rounded-lg`}
            >
              <Bot className="h-5 w-5" />
              <span>AI Assistant</span>
            </button>
            {session ? (
              <Button onClick={handleSignOut}>Sign Out</Button>
            ) : (
              <Button onClick={handleSignIn}>Sign In</Button>
            )}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-6 py-8">
        <SearchBox />
        {activeTab === "home" && <HomeContent />}
        {activeTab === "instagram" && <InstagramContent />}
        {activeTab === "youtube" && <YouTubeContent />}
        {activeTab === "twitter" && <TwitterContent />}
      </main>

      {showChat && <AIChat setShowChat={setShowChat} getPlatformColor={getPlatformColor} />}
    </div>
  )
}

export default MainDashboard

