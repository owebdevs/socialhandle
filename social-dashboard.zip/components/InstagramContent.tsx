import StatCard from "@/components/StatCard"
import SuggestionCard from "@/components/SuggestionCard"
import { Users, TrendingUp, Share2, Globe, Clock, Calendar, Hash, Target, BarChart2, RefreshCcw } from "lucide-react"

const InstagramContent = () => {
  // TODO: Implement real-time data fetching from Instagram API
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Total Followers" value="25.8K" icon={Users} trend={2.5} />
        <StatCard title="Engagement Rate" value="4.8%" icon={TrendingUp} trend={-0.3} />
        <StatCard title="Avg. Reel Views" value="12.3K" icon={Share2} trend={5.2} />
        <StatCard title="Post Reach" value="45.2K" icon={Globe} trend={1.8} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SuggestionCard
          title="Content Strategy Recommendations"
          suggestions={[
            {
              icon: <Clock className="h-4 w-4" />,
              title: "Optimal Posting Times",
              description: "Post between 6-8 PM EST for maximum engagement",
            },
            {
              icon: <Calendar className="h-4 w-4" />,
              title: "Posting Frequency",
              description: "Aim for 4-5 posts per week, including 2-3 Reels",
            },
            {
              icon: <Hash className="h-4 w-4" />,
              title: "Trending Hashtags",
              description: "#sustainableliving #wellness #techlife",
            },
          ]}
        />
        <SuggestionCard
          title="Growth Opportunities"
          suggestions={[
            {
              icon: <Target className="h-4 w-4" />,
              title: "Target Audience",
              description: "25-34 age group showing highest engagement",
            },
            {
              icon: <BarChart2 className="h-4 w-4" />,
              title: "Content Type Performance",
              description: "Reels getting 2.5x more engagement than static posts",
            },
            {
              icon: <RefreshCcw className="h-4 w-4" />,
              title: "Similar Accounts",
              description: "@techinfluencer, @digitalcreator showing similar growth",
            },
          ]}
        />
      </div>
    </div>
  )
}

export default InstagramContent

