import StatCard from "@/components/StatCard"
import SuggestionCard from "@/components/SuggestionCard"
import { Users, TrendingUp, Play, Clock, Calendar, Target, BarChart2, RefreshCcw } from "lucide-react"

const YouTubeContent = () => {
  // TODO: Implement real-time data fetching from YouTube API
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Subscribers" value="50.2K" icon={Users} trend={3.7} />
        <StatCard title="Total Views" value="1.2M" icon={TrendingUp} trend={2.1} />
        <StatCard title="Avg. Watch Time" value="5:32" icon={Clock} trend={0.8} />
        <StatCard title="Latest Video Views" value="25.6K" icon={Play} trend={4.3} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SuggestionCard
          title="Content Strategy Recommendations"
          suggestions={[
            {
              icon: <Clock className="h-4 w-4" />,
              title: "Optimal Upload Times",
              description: "Upload between 2-4 PM EST for maximum initial views",
            },
            {
              icon: <Calendar className="h-4 w-4" />,
              title: "Upload Frequency",
              description: "Aim for 2-3 videos per week for consistent growth",
            },
            {
              icon: <Target className="h-4 w-4" />,
              title: "Trending Topics",
              description: "Tech reviews, DIY projects, and lifestyle vlogs are trending",
            },
          ]}
        />
        <SuggestionCard
          title="Growth Opportunities"
          suggestions={[
            {
              icon: <BarChart2 className="h-4 w-4" />,
              title: "Top Performing Content",
              description: "Tutorial videos getting 3x more engagement",
            },
            {
              icon: <RefreshCcw className="h-4 w-4" />,
              title: "Collaboration Opportunities",
              description: "@techreviewchannel, @diyguru showing interest in collabs",
            },
            {
              icon: <Target className="h-4 w-4" />,
              title: "Audience Retention",
              description: "First 30 seconds crucial for retention. Hook viewers early!",
            },
          ]}
        />
      </div>
    </div>
  )
}

export default YouTubeContent

