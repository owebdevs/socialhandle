"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

const SearchBox = () => {
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearch = async () => {
    // TODO: Implement search functionality and analytics
    console.log("Searching for:", searchQuery)
  }

  return (
    <div className="mb-6 flex space-x-2">
      <Input
        type="text"
        placeholder="Search for Instagram handle..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="flex-grow"
      />
      <Button onClick={handleSearch}>
        <Search className="h-4 w-4 mr-2" />
        Search
      </Button>
    </div>
  )
}

export default SearchBox

