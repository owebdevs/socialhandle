import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const SuggestionCard = ({ title, suggestions }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-lg">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <ul className="space-y-3">
        {suggestions.map((suggestion, idx) => (
          <li key={idx} className="flex items-start space-x-2">
            <div className="p-1 rounded bg-gray-100">{suggestion.icon}</div>
            <div>
              <p className="font-medium">{suggestion.title}</p>
              <p className="text-sm opacity-70">{suggestion.description}</p>
            </div>
          </li>
        ))}
      </ul>
    </CardContent>
  </Card>
)

export default SuggestionCard

