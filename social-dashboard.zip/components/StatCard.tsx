import { Card, CardContent } from "@/components/ui/card"

const StatCard = ({ title, value, icon: Icon, trend }) => (
  <Card>
    <CardContent className="p-4">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm opacity-70">{title}</p>
          <h3 className="text-2xl font-bold mt-1">{value}</h3>
        </div>
        <Icon className="h-5 w-5" />
      </div>
      {trend && (
        <div className="mt-2 text-sm">
          <span className={trend > 0 ? "text-green-500" : "text-red-500"}>
            {trend > 0 ? "↑" : "↓"} {Math.abs(trend)}%
          </span>
          <span className="opacity-70 ml-1">vs last week</span>
        </div>
      )}
    </CardContent>
  </Card>
)

export default StatCard

