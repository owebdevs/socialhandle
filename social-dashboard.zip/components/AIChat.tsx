"use client"

import { useState } from "react"
import { Bot, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const AIChat = ({ setShowChat, getPlatformColor }) => {
  const [chatMessages, setChatMessages] = useState([
    { role: "bot", content: "Hi! I'm your AI assistant. Ask me anything about growing your social media presence!" },
  ])
  const [messageInput, setMessageInput] = useState("")

  const handleSendMessage = async () => {
    if (messageInput.trim()) {
      setChatMessages([...chatMessages, { role: "user", content: messageInput }])
      setMessageInput("")

      // TODO: Implement AI response using AI SDK
      const aiResponse = "This is a placeholder AI response. Implement actual AI logic here."
      setChatMessages((prev) => [...prev, { role: "bot", content: aiResponse }])
    }
  }

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-xl border">
      <div className="flex justify-between items-center p-4 border-b">
        <div className="flex items-center space-x-2">
          <Bot className="h-5 w-5 text-blue-500" />
          <span className="font-medium">AI Assistant</span>
        </div>
        <button onClick={() => setShowChat(false)} className="text-gray-500 hover:text-gray-700">
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="h-96 overflow-y-auto p-4 space-y-4">
        {chatMessages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                msg.role === "user" ? getPlatformColor().primary + " text-white" : "bg-gray-100 dark:bg-gray-700"
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 border-t">
        <div className="flex space-x-2">
          <Input
            type="text"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            placeholder="Ask about growing your social media..."
            className="flex-1"
          />
          <Button onClick={handleSendMessage} className={getPlatformColor().primary}>
            Send
          </Button>
        </div>
      </div>
    </div>
  )
}

export default AIChat

