const NavItem = ({ id, icon: Icon, label, activeTab, setActiveTab, theme }) => (
  <div
    onClick={() => setActiveTab(id)}
    className={`flex items-center space-x-2 p-3 rounded-lg cursor-pointer
      ${
        activeTab === id
          ? theme === "dark"
            ? "bg-gray-700 text-white"
            : "bg-blue-100 text-blue-600"
          : theme === "dark"
            ? "hover:bg-gray-700"
            : "hover:bg-gray-100"
      }`}
  >
    <Icon className="h-5 w-5" />
    <span>{label}</span>
  </div>
)

export default NavItem

